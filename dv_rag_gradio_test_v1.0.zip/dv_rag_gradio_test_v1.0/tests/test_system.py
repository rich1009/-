import json,hashlib,threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pytest
from config import Config
from service import Service
from risk import risk
from models import EmotionDetector,Ollama
from rag import RAG
from reporting import Reporter

class FakeModel:
    def __init__(self,config): self.config=config
    def embed(self,texts,query=False):
        v=np.array([[b+1 for b in hashlib.sha256(t.encode()).digest()] for t in texts],dtype='float32')
        return v/np.linalg.norm(v,axis=1,keepdims=True)
    def chat(self,messages,model=None,structured=False):
        if structured: return json.dumps({'fear':0.8,'despair':0.1,'evidence':['害怕']})
        return '已收到你的訊息，請告訴我現在是否安全。'

@pytest.fixture
def service(tmp_path):
    cfg=Config(data=tmp_path,emotion_llm=False)
    s=Service(cfg,FakeModel(cfg))
    for name,role in [('alice','client'),('bob','client'),('staff','staff')]: s.db.add_user(name,'test_password_123',role)
    return s

def test_auth_role_isolation(service):
    assert service.db.authenticate('alice','test_password_123','client')
    assert not service.db.authenticate('alice','test_password_123','staff')
    assert not service.db.authenticate('alice','wrong','client')
    with pytest.raises(PermissionError): service.staff_detail('alice',service.db.own_case('bob')['id'])
    with pytest.raises(PermissionError): service.ingest('alice',[])
    with pytest.raises(PermissionError): service.client_refresh('staff')

def test_multiple_clients_and_priority(service):
    with ThreadPoolExecutor(2) as pool:
        list(pool.map(lambda x:service.send(*x),[('alice','他現在拿刀要殺我，我很害怕'),('bob','我想問如何取得協助')]))
    a=service.db.own_case('alice');b=service.db.own_case('bob')
    assert a['priority']==4 and b['priority']<4
    assert service.db.dashboard('staff')[0]['id']==a['id']
    assert all('拿刀' not in m['content'] for m in service.db.messages(b['id']))
    events=service.db.reports('staff',a['id'])
    assert len(events)==1 and events[0]['status']=='simulated'

def test_human_handoff(service):
    cid=service.db.own_case('alice')['id']
    service.staff_reply('staff',cid,'我是社工，可以在這裡協助你。')
    service.send('alice','謝謝，我很害怕')
    assert not any(m['role']=='bot' for m in service.db.messages(cid))
    assert service.db.own_case('alice')['priority']>=2
    service.acknowledge('staff',cid)
    assert service.db.case(cid)['priority']==0
    service.set_mode('staff',cid,'bot');service.send('alice','你好')
    assert service.db.messages(cid)[-1]['role']=='bot'

@pytest.mark.parametrize('text',['我沒有自殺','他沒有打我','我在電影看到他現在拿刀','以前他現在拿刀是我寫的例句','如果他現在拿刀怎麼辦','廚房有刀子','我很絕望'])
def test_not_auto_dispatch(service,text):
    result=risk(text,service.db.rules(),service.detector.lexical(text))
    assert not result['emergency']

def test_negated_rules(service):
    assert risk('他沒有打我',service.db.rules(),service.detector.lexical('他沒有打我'))['score']==0
    assert service.detector.lexical('我不害怕')['fear']==0
    assert service.detector.lexical('我沒有希望')['despair']>0.65

def test_emotion_model_and_failure(service):
    detector=EmotionDetector(service.model)
    assert detector.detect('我很害怕')['method']=='ollama_context_classifier'
    service.model.chat=lambda *a,**kw:'bad-json'
    assert detector.detect('我很害怕')['method']=='lexical_fallback'

def test_rag_persistence_duplicates_model_identity(service,tmp_path):
    assert service.seed_index('staff').startswith('新增')
    old=len(service.rag.docs)
    service.seed_index('staff');assert len(service.rag.docs)==old
    reloaded=RAG(service.config.data/'index',service.model)
    assert reloaded.search('害怕') and reloaded.index.ntotal==old
    service.config.embed_model='other-model'
    bad=RAG(service.config.data/'index',service.model)
    assert bad.index is None and '模型不同' in bad.status

def test_model_outage_still_saves(service):
    service.model.chat=lambda *a,**kw:(_ for _ in ()).throw(RuntimeError('offline'))
    service.send('alice','他現在拿刀要殺我')
    cid=service.db.own_case('alice')['id']
    assert service.db.case(cid)['priority']==4
    assert service.db.reports('staff',cid)
    assert '無法使用' in service.db.messages(cid)[-1]['content']

def test_reporting_ack_retry_idempotency(service):
    service.config.report_mode='webhook';service.config.webhook='https://receiver.invalid/report'
    service.send('alice','他現在拿刀要殺我')
    cid=service.db.own_case('alice')['id'];calls=[]
    def fail(*a,**kw): calls.append(kw['headers']['Idempotency-Key']);raise TimeoutError()
    reporter=Reporter(service.db,service.config,fail);reporter.tick()
    assert service.db.reports('staff',cid)[0]['status']=='retry'
    with service.db.connect() as c: c.execute('UPDATE outbox SET next_try=0')
    def ok(*a,**kw):
        calls.append(kw['headers']['Idempotency-Key'])
        return SimpleNamespace(status_code=202,raise_for_status=lambda:None,json=lambda:{'accepted':True,'receipt_id':'TEST-123'})
    reporter.transport=ok;reporter.tick()
    assert calls[0]==calls[1]
    assert service.db.reports('staff',cid)[0]['receipt']=='TEST-123'

def test_ui_build(service):
    from app import build_apps
    client,staff=build_apps(service)
    assert client.get_config_file() and staff.get_config_file()
    client.close();staff.close()

def test_actual_ollama_http_adapter(tmp_path):
    from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            p=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            if self.path=='/api/embed':
                assert p['input'][0].startswith('search_')
                result={'embeddings':[[1,2,3] for _ in p['input']]}
            else: result={'message':{'content':'測試模型回覆'}}
            body=json.dumps(result).encode();self.send_response(200);self.end_headers();self.wfile.write(body)
        def log_message(self,*args): pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        model=Ollama(Config(data=tmp_path,ollama=f'http://127.0.0.1:{server.server_port}'))
        assert model.embed(['測試']).shape==(1,3)
        assert model.chat([{'role':'user','content':'你好'}])=='測試模型回覆'
    finally: server.shutdown();server.server_close()

def test_staff_can_interrupt_inflight_generation(service):
    entered=threading.Event();release=threading.Event()
    def slow(*args,**kwargs):
        entered.set();assert release.wait(5);return 'AI stale reply'
    service.model.chat=slow
    cid=service.db.own_case('alice')['id']
    with ThreadPoolExecutor(1) as pool:
        future=pool.submit(service.send,'alice','我需要幫忙')
        assert entered.wait(5)
        service.staff_reply('staff',cid,'我現在接手')
        release.set();future.result(timeout=5)
    assert not any(m['content']=='AI stale reply' for m in service.db.messages(cid))
    assert service.db.case(cid)['mode']=='human'

def test_persistence_after_restart(service):
    service.send('alice','他現在拿刀要殺我')
    restarted=Service(service.config,FakeModel(service.config))
    cid=restarted.db.own_case('alice')['id']
    assert restarted.db.case(cid)['priority']==4
    assert restarted.db.messages(cid)
    assert restarted.db.reports('staff',cid)[0]['status']=='simulated'

def test_webhook_no_receipt_is_not_success(service):
    service.config.report_mode='webhook';service.config.webhook='https://receiver.invalid/report'
    service.send('alice','他現在拿刀要殺我')
    response=SimpleNamespace(status_code=200,raise_for_status=lambda:None,json=lambda:{'ok':True})
    reporter=Reporter(service.db,service.config,lambda *args,**kwargs:response);reporter.tick()
    cid=service.db.own_case('alice')['id']
    assert service.db.reports('staff',cid)[0]['status']=='retry'
