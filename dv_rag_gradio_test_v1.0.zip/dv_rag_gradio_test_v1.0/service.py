import threading,json
from pathlib import Path
from database import Database
from models import Ollama,EmotionDetector
from rag import RAG,extract
from risk import risk
from reporting import Reporter

class Service:
    def __init__(self,config,model=None):
        config.validate();self.config=config
        self.db=Database(config.data/'cases.sqlite3')
        if not self.db.rules(): self.db.load_rules(json.loads((Path(__file__).parent/'knowledge/rules.json').read_text()))
        self.model=model or Ollama(config)
        self.rag=RAG(config.data/'index',self.model)
        self.detector=EmotionDetector(self.model,config.emotion_llm)
        self.reporter=Reporter(self.db,config)
        self.lock=threading.Lock();self.case_locks={}
    def case_lock(self,cid):
        with self.lock: return self.case_locks.setdefault(cid,threading.RLock())
    def transcript(self,cid):
        return [{'role':'user' if m['role']=='client' else 'assistant','content':('【社工】' if m['role']=='staff' else '')+m['content']} for m in self.db.messages(cid)]
    def client_refresh(self,actor):
        case=self.db.own_case(actor)
        return self.transcript(case['id']), '社工回覆模式' if case['mode']=='human' else 'AI 回覆模式'
    def send(self,actor,text):
        text=text.strip()
        if not text or len(text)>8000: raise ValueError('訊息須為 1 至 8000 字')
        case=self.db.own_case(actor);cid=case['id']
        with self.case_lock(cid):
            # Save and screen before any slow model request; emergency outbox is immediately visible.
            mid=self.db.add_message(cid,'client',text)
            lexical=self.detector.lexical(text)
            baseline=risk(text,self.db.rules(),lexical)
            self.db.analysis(cid,mid,baseline,self.config.report_mode)
            emotion=self.detector.detect(text)
            result=risk(text,self.db.rules(),emotion)
            docs=[]
            try: docs=self.rag.search(text)
            except Exception as e: result['retrieval_error']=type(e).__name__
            result['sources']=docs
            self.db.analysis(cid,mid,result,self.config.report_mode)
            if self.db.case(cid)['mode']=='bot':
                try:
                    history=[{'role':'user' if m['role']=='client' else 'assistant','content':m['content']} for m in self.db.messages(cid) if m['id']!=mid]
                    answer=self.rag.answer(text,history,docs)
                except Exception:
                    answer='訊息已保存，AI 回覆目前無法使用。請等候社工查看；若有立即危險，請使用所在地的緊急求助管道。'
                if result['emergency']:
                    answer='系統偵測到可能的立即危險，已將訊息列為緊急待處理。這不代表警方已受理或救援已出發。\n\n'+answer
                self.db.bot_message(cid,answer)
            return self.client_refresh(actor)
    def staff_reply(self,actor,cid,text):
        self.db.require(actor,'staff')
        if not text.strip() or len(text)>8000: raise ValueError('回覆須為 1 至 8000 字')
        self.db.staff_mode(actor,cid,'human');self.db.add_message(cid,'staff',text.strip())
        return self.staff_detail(actor,cid)
    def staff_detail(self,actor,cid):
        self.db.require(actor,'staff');case=self.db.case(cid)
        return self.transcript(cid), {'case_id':cid,'owner':case['owner'],'mode':case['mode'],'priority':case['priority'],'score':case['score'],'latest_assessment':json.loads(case['risk']),'reports':self.db.reports(actor,cid)}
    def set_mode(self,actor,cid,mode):
        self.db.require(actor,'staff')
        self.db.staff_mode(actor,cid,mode)
        return self.staff_detail(actor,cid)
    def acknowledge(self,actor,cid):
        self.db.require(actor,'staff')
        with self.case_lock(cid): self.db.acknowledge(actor,cid)
        return self.staff_detail(actor,cid)
    def ingest(self,actor,files):
        self.db.require(actor,'staff')
        if not files: raise ValueError('請先選擇文件')
        added=0
        for file in files: added+=self.rag.add(extract(file),Path(file).name)
        return f'新增 {added} 段；'+self.rag.status
    def seed_index(self,actor):
        self.db.require(actor,'staff')
        rules=self.db.rules()
        text='\n'.join(v['zh']+'：'+ '、'.join(v['terms'])+f'。規則權重 {v["weight"]}。' for v in rules.values())
        return f'新增 {self.rag.add(text,"家暴關鍵用語規則")} 段；'+self.rag.status
