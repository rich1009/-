# 免密碼測試版

此版本供本機測試，不需要建立帳號或輸入密碼。

## 啟動

解壓縮並進入 `dv_rag_gradio_test`，在原本的 Python 環境執行：

```bash
export CHAT_MODEL='mistral-small3.2:latest'
export EMOTION_MODEL='mistral-small3.2:latest'
export EMBED_MODEL='nomic-embed-text'
python app.py run
```

首次安裝依賴可執行 `python -m pip install -r requirements-lock.txt`。

- 個案介面：http://127.0.0.1:7860，直接選擇 `test_case_001`、`test_case_002` 或 `test_case_003`。
- 社工介面：http://127.0.0.1:7862，直接開啟即可查看及回覆。
- 用不同瀏覽器分頁選不同個案，即可測試多人傳訊。
- 模型、資料上傳、RAG、情緒判讀及社工接手操作方式與原版一致。

測試資料獨立保存在本版本的 `data_test/`，不會讀取原版的帳號或對話。預設沒有知識庫索引，請在社工頁面加入規則及上傳文件。測試版固定 localhost、`share=False`、模擬通報，忽略環境中的正式通報設定。沒有開啟實際通報工作流程。

免登入表示任何能連到服務的人均可查看社工介面與切換測試個案，請僅使用虛構資料。正式使用請回到有帳號密碼的版本。從另一台電腦測試可透過 SSH 轉接兩個 port。

原版技術說明請見 `README_FULL.md`；其中帳號建立、角色驗證及正式通報章節不適用於本免密碼入口。

## 測試結果

本次 23 個測試全部通過，包含實際 Gradio HTTP 免登入、兩個測試個案同時傳訊、個案切換、社工回覆及模擬通報。模型測試採假模型；真實 Ollama 模型可執行 `python check_models.py` 另行確認。

## 個案選單更新修正

修正社工下拉選單在選項尚未載入或瀏覽器保留舊值時，出現 `is not in the list of choices: []` 的問題。啟動時載入已有個案；每次刷新同步更新清單、選取值與詳情；背景更新不再觸發額外的選單 change 事件。個案 ID 的有效性仍由後端資料庫核對。

更新已有測試版時，停止程式後，只須替換 `app.py`（其餘程式相容），重新執行 `python app.py run`，並關閉舊頁籤或按 Ctrl+F5 重新載入。保留原本的 `data_test/`，不需刪除資料或重建索引。
