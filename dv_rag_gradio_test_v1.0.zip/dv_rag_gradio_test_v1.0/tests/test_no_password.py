from concurrent.futures import ThreadPoolExecutor
from gradio_client import Client
from config import Config
from service import Service
from app import build_apps
from test_system import FakeModel
from test_live_ui import port

def test_no_password_client_and_staff(tmp_path):
    cfg=Config(data=tmp_path,emotion_llm=False)
    svc=Service(cfg,FakeModel(cfg))
    client,staff=build_apps(svc,test_mode=True)
    try:
        cp,sp=port(),port()
        client.launch(server_name='127.0.0.1',server_port=cp,auth=None,prevent_thread_lock=True,quiet=True)
        staff.launch(server_name='127.0.0.1',server_port=sp,auth=None,prevent_thread_lock=True,quiet=True)
        first=Client(f'http://127.0.0.1:{cp}',verbose=False)
        second=Client(f'http://127.0.0.1:{cp}',verbose=False)
        worker=Client(f'http://127.0.0.1:{sp}',verbose=False)
        with ThreadPoolExecutor(2) as pool:
            f=pool.submit(first.predict,'他現在拿刀要殺我','test_case_001',api_name='/send_message')
            g=pool.submit(second.predict,'你好，我想詢問協助','test_case_002',api_name='/send_message')
            f.result(timeout=30);g.result(timeout=30)
        assert '拿刀' in str(first.predict('test_case_001',api_name='/refresh'))
        assert '拿刀' not in str(second.predict('test_case_002',api_name='/refresh'))
        worker.predict(None,api_name='/list_cases')
        cid=svc.db.own_case('test_case_001')['id']
        worker.predict(cid,'我是測試社工，已接手',api_name='/staff_reply')
        assert '我是測試社工' in str(first.predict('test_case_001',api_name='/refresh'))
        assert svc.db.reports('test_worker',cid)[0]['status']=='simulated'
    finally:client.close();staff.close()
