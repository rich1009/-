import json,time,threading
import requests

class Reporter:
    def __init__(self,db,config,transport=None):
        self.db=db;self.config=config;self.transport=transport or requests.post
        self.stop_event=threading.Event();self.thread=None
    def tick(self):
        if self.config.report_mode!='webhook': return
        with self.db.connect() as c:
            # Single-process durable worker; recover uncertain deliveries on startup.
            rows=[dict(x) for x in c.execute("SELECT * FROM outbox WHERE status IN ('pending','retry') AND next_try<=?",(time.time(),))]
        for row in rows:
            attempts=row['attempts']+1
            with self.db.connect() as c:
                claimed=c.execute("UPDATE outbox SET status='sending',attempts=? WHERE id=? AND status IN ('pending','retry')",(attempts,row['id'])).rowcount
            if not claimed: continue
            try:
                headers={'Idempotency-Key':row['message_id']}
                if self.config.webhook_token: headers['Authorization']='Bearer '+self.config.webhook_token
                response=self.transport(self.config.webhook,json=json.loads(row['payload']),headers=headers,timeout=15,allow_redirects=False)
                response.raise_for_status()
                receipt=response.json()
                # The receiver MUST return a recorded acceptance and reference ID.
                if response.status_code not in (200,201,202) or receipt.get('accepted') is not True or not receipt.get('receipt_id'):
                    raise ValueError('介接端未回傳 accepted=true 及 receipt_id')
                with self.db.connect() as c:
                    c.execute("UPDATE outbox SET status='accepted',receipt=?,error='' WHERE id=?",(str(receipt['receipt_id'])[:200],row['id']))
            except Exception as e:
                with self.db.connect() as c:
                    c.execute('UPDATE outbox SET status=?,error=?,next_try=? WHERE id=?',('failed' if attempts>=5 else 'retry',type(e).__name__,time.time()+min(300,2**attempts),row['id']))
    def start(self):
        with self.db.connect() as c: c.execute("UPDATE outbox SET status='retry',next_try=0 WHERE status='sending'")
        def loop():
            while not self.stop_event.is_set():
                try: self.tick()
                except Exception: pass # Persistent state remains; next tick retries.
                self.stop_event.wait(2)
        self.thread=threading.Thread(target=loop,daemon=True);self.thread.start()
    def retry(self,actor,event_id):
        self.db.require(actor,'staff')
        with self.db.connect() as c:
            c.execute("UPDATE outbox SET status='pending',attempts=0,next_try=0 WHERE id=? AND status='failed'",(event_id,))
            c.execute('INSERT INTO audit(actor,action,case_id,created) VALUES(?,?,?,?)',(actor,'retry_report:'+event_id,'',time.time()))
