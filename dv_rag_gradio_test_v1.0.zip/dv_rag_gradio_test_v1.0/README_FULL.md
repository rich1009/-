# 家暴防治 RAG 與社工工作台

本專案將原本 React／Vite＋FastAPI 的家暴初篩專案，改寫為兩個 Gradio 介面：個案對話與社工工作台。利用本機 Ollama 的 `nomic-embed-text` 建立 FAISS 索引，以關鍵字規則和情緒判讀排序待處理個案，並保存對話與通報事件。

這是可以執行與測試的研究原型，尚未經臨床、家暴實務或警政驗證。**預設只記錄測試通報，不會真的報警。** 正式通報須另接收單位提供的授權 HTTPS 介接；HTTP 接收回執不等同警方受理、派遣或救援完成。

## 功能

- 個案登入後只能存取自己的對話；社工使用獨立登入介面。
- 多個案同時傳送訊息，Gradio 每個介面併發上限 8，SQLite WAL 保存資料。
- 同一個案訊息依序處理，社工可即時切換人工模式，阻止正在生成的 AI 回覆寫入。
- 每則訊息先存檔、做規則初篩，再執行情緒模型與 RAG；緊急訊息不等待模型完成才建立通報事件。
- 中文情緒偵測器以 Ollama 結構化 JSON 判讀恐懼／絕望，區分當事人、引用、否定及歷史語境。這是 LLM 分類器，**不是另有驗證的心理量表或專門訓練的情緒模型**。
- 情緒模型失敗時退回關鍵字推估，社工會看見降級狀態，系統不假裝模型成功。
- 家暴關鍵用語、可調權重放在 `knowledge/rules.json`，初始化時寫入 SQLite 規則表。
- 社工可將關鍵用語加入 FAISS，也可上傳 TXT、MD、PDF、DOCX、JSON、JSONL、CSV 文件。
- 檢索使用 `search_document:`／`search_query:` 前綴、向量正規化和 `IndexFlatIP`，以餘弦相似度排序。
- AI 根據檢索片段回答並使用 `[1]` 等來源編號；來源原文與相似度可在社工工作台核對。引用由模型產生，仍需核對。
- 高風險或高恐懼／絕望者優先排序；警示不因下一則平靜訊息而自動消失，直到社工檢視後重設。
- 人工接手、優先級重設及通報重試寫入稽核紀錄。
- 持久化通報佇列具重試、回執與冪等事件 ID，重啟後可恢復待送事件。

## 架構及評分方式

| 模組 | 工作 |
| --- | --- |
| `app.py` | 兩個 Gradio 介面、登入與啟動指令 |
| `service.py` | 個案流程、人工接手、資料管理 |
| `database.py` | 帳號、個案、訊息、規則、通報與稽核 |
| `models.py` | Ollama embedding／生成／情緒分類 |
| `rag.py` | 文件讀取、分段、FAISS 搜尋與索引快照 |
| `risk.py` | 關鍵用語評分、情緒加分、緊急情境規則 |
| `reporting.py` | 通報 outbox 與 HTTPS webhook 接收回執 |
| `check_models.py` | 在你的電腦驗證真實 Ollama 模型 |

每個分類的規則權重乘上不同命中詞的數量，上限為 3；若恐懼或絕望估計值 ≥ 0.65，額外加 12 分。優先級為：

| 優先級 | 條件 |
| --- | --- |
| 4 緊急 | 命中當下生命危險的明確原型情境規則 |
| 3 高 | 總分 ≥ 25，或高情緒加上家暴分類命中 |
| 2 中 | 總分 ≥ 10，或高恐懼／絕望 |
| 1 低 | 有規則分數但未達以上門檻 |
| 0 未偵測 | 沒有命中；不代表確定安全 |

這些數字是**可修改的原型啟發式門檻，沒有經過統計校準**。FAISS 相似度用於取回參考資料，不直接視為家暴危險分數；「刀子」等單一名詞、情緒高分、或只達高風險門檻，不會單獨觸發正式通報。自動通報另由 `risk.py` 中當下生命危險規則決定，包含持刀殺人、勒頸不能呼吸及當下明確自殺意圖等訊號。否定、小說、假設、歷史語境會嘗試排除，但規則仍可能誤判或漏判。實際採用前須由專業單位以標註語料驗證與調整。

## 安裝與啟動

建議 Python 3.11 或 3.12；本次實測 Python 3.12。解壓縮後進入 `dv_rag_gradio`。`requirements-lock.txt` 固定本次實測依賴版本；`requirements.txt` 提供可升級範圍，升級後請重新測試。

### 1. 建立 Python 環境

Linux／macOS：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-lock.txt
```

Windows PowerShell：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements-lock.txt
```

### 2. 準備 Ollama

安裝 [Ollama](https://ollama.com/) 後，確保服務啟動。若已在背景執行，不需要再啟動第二個服務。

```bash
ollama serve
```

另一個終端機下載模型：

```bash
ollama pull nomic-embed-text
ollama pull llama3.1:8b
python check_models.py
```

`check_models.py` 必須全部 PASS，才能確認你機器上的真實 embedding、情緒判讀與文字生成可用。這個指令不建立個案，也不呼叫報案 webhook。

### 3. 建立社工與個案帳號

```bash
python app.py add-user --username social_worker --role staff
python app.py add-user --username case_001 --role client
python app.py add-user --username case_002 --role client
```

互動輸入至少 8 個字元的密碼；密碼不放在指令參數或 GitHub。帳號密碼使用 PBKDF2-HMAC-SHA256、600,000 次迭代與隨機 salt 保存。帳號由管理者預先建立，沒有公開自助註冊。每個個案帳號建立唯一個案 ID。

### 4. 啟動

```bash
python app.py run
```

- 個案介面：`http://127.0.0.1:7860`
- 社工介面：`http://127.0.0.1:7862`

兩個介面在同一 Python 程序內啟動，以不同 port 隔離登入角色。啟動後社工登入，展開「知識庫管理」，先按「將家暴關鍵用語加入索引」，再上傳你準備的資料並按「加入 FAISS 索引」。建立初始索引需要 Ollama embedding 服務。

資料庫會自動建立；沒有索引時仍能記錄與初篩訊息，但 RAG 會明示沒有檢索資料。文字 PDF 可讀取，掃描 PDF 需先 OCR。單一上傳文件上限 20 MB；文件加入索引按相同來源和片段去重。

## 社工操作

1. 清單每 3 秒更新，依優先級、分數與最近活動排序。
2. 選擇個案，檢查對話、命中詞、情緒判讀方法、檢索資料與通報狀態。
3. 按「接手並回覆」後切換人工模式，後續個案訊息仍持續評分，但不再由 AI 回覆。
4. 完成檢視後可「已檢視／重設優先級」；此動作不刪除歷史評分或通報。
5. 需要時按「恢復 AI 回覆」。

清單上的分數及優先級保留自上次重設以來的最高值，詳細 JSON 顯示最新訊息評估。兩者可能不同。個案對話也每 3 秒輪詢社工回覆。頁面關閉不會刪除對話；社工再次開啟會讀到持久化資料。

## 模型與環境設定

程式讀取環境變數；`.env.example` 是說明範本，**不會自動載入 `.env`**。

Linux：

```bash
export CHAT_MODEL='你已安裝的模型名稱'
export EMOTION_MODEL='你已安裝的模型名稱'
export OLLAMA_URL='http://127.0.0.1:11434'
python app.py run
```

PowerShell：

```powershell
$env:CHAT_MODEL='你已安裝的模型名稱'
$env:EMOTION_MODEL='你已安裝的模型名稱'
python app.py run
```

| 變數 | 預設 |
| --- | --- |
| `EMBED_MODEL` | `nomic-embed-text` |
| `CHAT_MODEL`、`EMOTION_MODEL` | `llama3.1:8b` |
| `EMOTION_LLM` | `true`；設 `false` 時僅關鍵字情緒推估 |
| `DV_DATA_DIR` | 專案下的 `data/` |
| `HOST` | `127.0.0.1` |
| `CLIENT_PORT`、`STAFF_PORT` | `7860`、`7862` |
| `REPORT_MODE` | `dry_run` |
| `REPORT_WEBHOOK_URL`、`REPORT_WEBHOOK_TOKEN` | 空值 |

修改 embedding 模型後須重建索引，不能混用不同向量空間。先停機，備份 `data/index/`，將該資料夾移走，再啟動並重新加入資料；不要刪除保存對話的 SQLite 資料庫。

修改規則檔後，先停機，再執行：

```bash
python -c "import json; from config import Config; from service import Service; from pathlib import Path; s=Service(Config()); s.db.load_rules(json.loads(Path('knowledge/rules.json').read_text(encoding='utf-8')))"
```

規則索引內容不會自動刪掉舊版本；修改後請重建 `data/index/` 並重新加入規則與文件。

## 自動通報介接

### 測試模式

`REPORT_MODE=dry_run`：緊急事件只記錄 `simulated`，不連外、不冒充報案成功。

### 正式 webhook 模式

取得接收單位授權的介接網址後，停機並設定：

```bash
export REPORT_MODE='webhook'
export REPORT_WEBHOOK_URL='https://接收單位提供的網址/report'
export REPORT_WEBHOOK_TOKEN='由接收單位提供的憑證'
python app.py run
```

這不是通用的 110 報案 API；程式不會自動撥打電話。需要接收端將事件轉交真正的通報流程，並且能以 `case_id` 對應當事人的聯絡資訊與所在地。本版沒有收集地址、定位或保護對象身分，因此不能單靠此 payload 完成警方出勤所需資料。

伺服器對 webhook 發送 POST，使用 `Authorization: Bearer ...`（若有設定）及 `Idempotency-Key: message_id`。payload 包含 `event_id`、`case_id`、`message_id`、觸發訊息、當時初篩結果和建立時間。通報內容採第一次緊急判定的快照，可能先於完整情緒模型判讀；完整後續結果保留在訊息分析中。

接收端須回傳 HTTP 200、201 或 202，JSON 格式為：

```json
{"accepted": true, "receipt_id": "接收單位的唯一回執"}
```

接收端須依 `Idempotency-Key` 去重。網路逾時可能發生「對方已收、此端未知」情況，重試沿用相同 ID；單靠本程式無法保證跨網路只送一次。

| 狀態 | 意義 |
| --- | --- |
| `simulated` | 測試事件，未送出 |
| `pending`／`sending` | 排程或傳送中 |
| `retry` | 等待重試 |
| `failed` | 已失敗 5 次，需社工處理或重送 |
| `accepted` | 介接端已接收且有回執，非警方受理或救援保證 |

重試間隔採指數退避，最多 5 次。重啟時恢復未完成傳送；失敗 ID 可在社工介面重送。切換正式模式不會補送舊的 `simulated` 事件。第一次部署先接單位提供的測試端，不要以真實個案測試。

## 測試與驗證範圍

```bash
python -m pytest -q tests
```

測試包含：

- 帳號角色隔離、個案資料隔離與多人併發。
- 明確危險置頂、否定／歷史／假設情境不直接自動通報。
- 人工接手與恢復 AI、警示重設。
- FAISS 建立、重載、去重與模型身份檢查。
- 情緒模型結構化輸出與模型故障降級。
- webhook 失敗重試、同一事件去重 ID 與回執。
- 真實 Gradio HTTP 服務、兩個個案登入、社工登入與回覆往返。
- Ollama HTTP 呼叫格式與向量正規化。

本次實測 Python 3.12、Gradio 6.30.0、FAISS 1.15.1，21 個測試通過（含真實 Gradio HTTP 登入與回覆測試）。Gradio／pandas 產生的棄用警告沒有影響測試結果。

自動化測試使用確定性的假模型和本機測試 HTTP 端；**測試向量不是 Nomic，測試回覆不是實際 LLM 推理，測試回執不是警政回執**。本次開發環境沒有安裝你的 Ollama 模型，也沒有警方或社福正式端點，所以未能驗證真實模型品質或正式報案。請另執行 `check_models.py`，再以至少兩個個案帳號做現場驗收；真正部署前須完成接收單位的端到端通報驗收。

## 部署及資料保護

本版適用單一主機、單一 Python 程序；不要對相同資料夾啟動多個程序或多個 replica。Gradio 的 8 個併發請求不代表模型同時能有效推理 8 人，實際容量由 Ollama 排程、GPU／CPU 與模型決定，尚未做大規模壓力測試。

預設只監聽本機且 `share=False`。外部使用時，需 HTTPS 反向代理、防火牆、登入速率限制及管理機制；不要直接暴露本版的開發 HTTP port。SQLite 保存的是明文對話，沒有提供磁碟加密、完整組織 RBAC、帳號恢復／撤銷 UI 或保存期限機制，需由部署單位補足。所有社工角色可查看所有個案；若需分派社工的細部權限，須再擴充。

共同 RAG 知識庫只應放一般指引與經授權的資料，不要把個案聊天記錄混入共用索引，以免跨個案檢索洩露個資。檢索文本也是不可信資料，系統提示已有資料與指令分離要求，但不能保證完全消除 prompt injection。帳號、訊息、通報、索引與秘密不得上傳 GitHub。

## 常見問題

- **模型連線失敗**：確認 Ollama 正在執行、模型名稱與 tag 正確，執行 `python check_models.py`。
- **port 已使用**：用 `CLIENT_PORT`／`STAFF_PORT` 設定不同的空閒 port，並保持兩者不同。
- **沒有索引**：由社工先加入規則與文件；確認 embedding 服務可用。
- **只看到關鍵字推估**：情緒模型停用、連線失敗、JSON 不合格式或模型能力不足；查看詳細 JSON 狀態。
- **社工已回覆但個案還沒看到**：等候輪詢，或按「更新社工回覆」。
- **自動通報未送出**：預設 dry_run；正式模式看 outbox 狀態與接收端回執。高風險分數本身不會觸發生命危險通報規則。
- **代理設定造成 localhost 問題**：讓 `127.0.0.1`／`localhost` 經 `NO_PROXY` 排除代理；如使用 SOCKS，額外安裝 `httpx[socks]` 與 `requests[socks]`。

## 上傳 GitHub

ZIP 不含帳號、對話、資料庫、索引或任何 webhook token；`.gitignore` 排除執行資料。

```bash
git init
git add .
git commit -m "Add Gradio domestic violence RAG prototype"
git branch -M main
git remote add origin https://github.com/你的帳號/你的repo.git
git push -u origin main
```

發布前確認 staged 檔案沒有真實個案或憑證。本交付沒有替你建立遠端 repository 或推送。

## 技術參考

- [Gradio 併發與佇列](https://www.gradio.app/guides/queuing)
- [Gradio 登入與部署](https://www.gradio.app/guides/sharing-your-app)
- [Ollama Nomic embedding](https://ollama.com/library/nomic-embed-text)
- [FAISS](https://github.com/facebookresearch/faiss)
