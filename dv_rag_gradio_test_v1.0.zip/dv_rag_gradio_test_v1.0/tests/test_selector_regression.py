"""Regression: valid IDs must survive empty/stale Gradio dropdown choices."""
import gradio as gr
import pytest
from gradio_client import Client
from config import Config
from service import Service
from app import build_apps
from test_system import FakeModel
from test_live_ui import port


def test_empty_dropdown_choices_and_stale_selection(tmp_path):
    cfg=Config(data=tmp_path,emotion_llm=False)
    svc=Service(cfg,FakeModel(cfg))
    client,staff=build_apps(svc,test_mode=True)
    selector=next(c for c in staff.blocks.values() if isinstance(c,gr.Dropdown) and c.label=='選擇個案')
    # Reproduce a session whose options have not arrived yet.
    selector.choices=[];selector.value=None
    cid=svc.db.own_case('test_case_002')['id']
    sp=port()
    try:
        staff.launch(server_name='127.0.0.1',server_port=sp,auth=None,prevent_thread_lock=True,quiet=True)
        worker=Client(f'http://127.0.0.1:{sp}',verbose=False)
        detail=worker.predict(cid,api_name='/case_detail')
        assert detail[1]['case_id']==cid
        poll=worker.predict(cid,api_name='/poll_cases')
        assert poll[1]['value']==cid==poll[3]['case_id']
        stale=worker.predict('deleted-or-stale-case',api_name='/poll_cases')
        assert stale[1]['value']==stale[3]['case_id']
        assert stale[3]['case_id'] in {svc.db.own_case(x)['id'] for x in ('test_case_001','test_case_002','test_case_003')}
        worker.predict(cid,'測試社工回覆',api_name='/staff_reply')
        assert svc.db.messages(cid)[-1]['content']=='測試社工回覆'
        before=sum(len(svc.db.messages(r['id'])) for r in svc.db.dashboard('test_worker'))
        with pytest.raises(Exception,match='有效的個案'):
            worker.predict('nonexistent','不可寫入',api_name='/staff_reply')
        after=sum(len(svc.db.messages(r['id'])) for r in svc.db.dashboard('test_worker'))
        assert before==after
    finally:client.close();staff.close()
