from dataclasses import dataclass
from pathlib import Path
import os

@dataclass
class Config:
    data: Path = Path(os.getenv('DV_DATA_DIR', str(Path(__file__).parent / 'data')))
    ollama: str = os.getenv('OLLAMA_URL', 'http://127.0.0.1:11434')
    embed_model: str = os.getenv('EMBED_MODEL', 'nomic-embed-text')
    chat_model: str = os.getenv('CHAT_MODEL', 'llama3.1:8b')
    emotion_model: str = os.getenv('EMOTION_MODEL', 'llama3.1:8b')
    webhook: str = os.getenv('REPORT_WEBHOOK_URL', '')
    webhook_token: str = os.getenv('REPORT_WEBHOOK_TOKEN', '')
    report_mode: str = os.getenv('REPORT_MODE', 'dry_run')
    emotion_llm: bool = os.getenv('EMOTION_LLM', 'true').lower() == 'true'
    host: str = os.getenv('HOST', '127.0.0.1')
    client_port: int = int(os.getenv('CLIENT_PORT', '7860'))
    staff_port: int = int(os.getenv('STAFF_PORT', '7862'))

    def validate(self):
        if self.report_mode not in ('dry_run', 'webhook'):
            raise ValueError('REPORT_MODE 必須為 dry_run 或 webhook')
        if self.report_mode == 'webhook' and not self.webhook.startswith('https://'):
            raise ValueError('正式通報介接須設定 HTTPS REPORT_WEBHOOK_URL')
        if self.client_port == self.staff_port:
            raise ValueError('兩種介面須使用不同 port')
