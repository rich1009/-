"""Run against your own installed Ollama models; does not send a report."""
from config import Config
from models import Ollama,EmotionDetector

if __name__=='__main__':
    c=Config();model=Ollama(c)
    try:
        v=model.embed(['家暴防治與安全計畫'])
        q=model.embed(['當事人感到害怕'],query=True)
        assert v.shape[1]==q.shape[1]
        print(f'PASS Nomic embedding: dimension={v.shape[1]}')
        emotion=EmotionDetector(model).detect('我很害怕，不知道該怎麼辦。')
        if emotion['method']!='ollama_context_classifier': raise RuntimeError(emotion['status'])
        print('PASS emotion classifier:',emotion)
        answer=model.chat([{'role':'user','content':'請用繁體中文說明你可以協助整理資訊，但不能保證安全。'}])
        print('PASS generation:',answer)
    except Exception as e:
        print('FAIL:',type(e).__name__,str(e));raise SystemExit(1)
