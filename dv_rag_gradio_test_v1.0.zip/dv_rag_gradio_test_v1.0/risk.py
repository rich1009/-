import re

# Prototype patterns: do not trigger reporting merely on a weapon noun or emotion.
URGENT=[r'(現在|正在|剛剛|馬上|此刻).{0,15}(拿刀|持刀|勒.*脖|掐.*脖|砍我|殺我|打死我|放火|開槍)',r'(他|她|對方).{0,8}(正在|現在).{0,8}(殺|砍|掐|勒)',r'(被|他|她).{0,6}(勒住脖子|掐住脖子).{0,10}(不能呼吸|無法呼吸|喘不過氣)',r'(現在|馬上).{0,10}(要自殺|要殺死自己|要結束生命)']
NEG=r'(?:沒有|並未|未曾|從未|不是|不會|並沒有|沒)(?:再|被|人|他|她|在|有|想|要|對我|真的){0,3}$'

def risk(text,rules,emotion):
    findings=[];score=0;categories=set()
    for category,cfg in rules.items():
        effective=[]
        for term in cfg['terms']:
            pattern=re.escape(term)
            if term.isascii() and term[0].isalpha(): pattern=r'\b'+pattern+r'\b'
            for m in re.finditer(pattern,text,re.I):
                before=text[max(0,m.start()-16):m.start()]
                if re.search(NEG,before): continue
                effective.append(term)
        if effective:
            points=cfg['weight']*min(len(set(effective)),3)
            score+=points;categories.add(category)
            findings.append({'category':category,'label':cfg['zh'],'terms':sorted(set(effective)),'points':points})
    emotional=max(emotion['fear'],emotion['despair'])>=0.65
    if emotional: score+=12
    matches=[]
    for pattern in URGENT:
        for m in re.finditer(pattern,text):
            sentence=re.split('[。！？!?\n]',text[max(0,m.start()-50):m.end()])[-1]
            # Explicit historical, hypothetical and negated framing suppresses automatic dispatch.
            if re.search(r'沒有|並未|並沒有|不會|不是|以前|去年|昨天|曾經|假如|如果|電影|小說|新聞|演戲|例句',sentence): continue
            matches.append(m.group())
    emergency=bool(matches)
    priority=4 if emergency else 3 if score>=25 or (emotional and categories) else 2 if emotional or score>=10 else 1 if score else 0
    return {'score':score,'priority':priority,'level':['未偵測','低','中','高','緊急'][priority],'emergency':emergency,'urgent_evidence':matches,'findings':findings,'emotion':emotion,'scoring':'原型規則分數，非已驗證的危險機率'}
