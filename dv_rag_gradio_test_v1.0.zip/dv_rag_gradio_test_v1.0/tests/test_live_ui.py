"""Real Gradio HTTP servers/client login with deterministic test model (not real LLM)."""
import socket
from concurrent.futures import ThreadPoolExecutor
from gradio_client import Client
import pytest
from config import Config
from service import Service
from app import build_apps
from test_system import FakeModel

def port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0));return s.getsockname()[1]

def test_live_authenticated_interfaces(tmp_path):
    cfg=Config(data=tmp_path,emotion_llm=False)
    svc=Service(cfg,FakeModel(cfg))
    for user,role in [('alice','client'),('bob','client'),('staff','staff')]:svc.db.add_user(user,'test_password_123',role)
    client,staff=build_apps(svc);cp,sp=port(),port()
    try:
        client.launch(server_name='127.0.0.1',server_port=cp,auth=lambda u,p:svc.db.authenticate(u,p,'client'),prevent_thread_lock=True,quiet=True)
        staff.launch(server_name='127.0.0.1',server_port=sp,auth=lambda u,p:svc.db.authenticate(u,p,'staff'),prevent_thread_lock=True,quiet=True)
        a=Client(f'http://127.0.0.1:{cp}',auth=('alice','test_password_123'),verbose=False)
        b=Client(f'http://127.0.0.1:{cp}',auth=('bob','test_password_123'),verbose=False)
        worker=Client(f'http://127.0.0.1:{sp}',auth=('staff','test_password_123'),verbose=False)
        with pytest.raises(Exception):Client(f'http://127.0.0.1:{sp}',auth=('alice','test_password_123'),verbose=False)
        with ThreadPoolExecutor(2) as pool:
            af=pool.submit(a.predict,'他現在拿刀要殺我，我很害怕',api_name='/send_message')
            bf=pool.submit(b.predict,'你好，我想問如何取得協助',api_name='/send_message')
            af.result(timeout=30);bf.result(timeout=30)
        ar=a.predict(api_name='/refresh');br=b.predict(api_name='/refresh')
        assert '拿刀' in str(ar) and '拿刀' not in str(br)
        cid=svc.db.own_case('alice')['id']
        worker.predict(None,api_name='/list_cases')
        detail=worker.predict(cid,api_name='/case_detail')
        assert detail[1]['priority']==4
        worker.predict(cid,'我是社工，現在由我協助你。',api_name='/staff_reply')
        ar=a.predict(api_name='/refresh')
        assert '我是社工' in str(ar) and '社工回覆模式' in str(ar)
    finally:client.close();staff.close()
