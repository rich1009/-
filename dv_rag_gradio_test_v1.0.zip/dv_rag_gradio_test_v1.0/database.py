import sqlite3, json, uuid, hashlib, secrets, hmac, time
from contextlib import contextmanager

class Database:
    def __init__(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = str(path)
        with self.connect() as c:
            c.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY,role TEXT,salt TEXT,hash TEXT);
            CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY,owner TEXT UNIQUE,mode TEXT DEFAULT 'bot',priority INTEGER DEFAULT 0,score REAL DEFAULT 0,risk TEXT DEFAULT '{}',updated REAL);
            CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,case_id TEXT,role TEXT,content TEXT,created REAL,analysis TEXT DEFAULT '{}');
            CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY,message_id TEXT UNIQUE,case_id TEXT,payload TEXT,status TEXT,attempts INTEGER DEFAULT 0,next_try REAL DEFAULT 0,error TEXT DEFAULT '',receipt TEXT DEFAULT '');
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor TEXT,action TEXT,case_id TEXT,created REAL);
            CREATE TABLE IF NOT EXISTS rules(category TEXT PRIMARY KEY,config TEXT);
            ''')
    @contextmanager
    def connect(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        try:
            with c: yield c
        finally: c.close()
    def add_user(self, username, password, role):
        if role not in ('client','staff') or not username.strip() or len(password)<8:
            raise ValueError('角色須為 client/staff；密碼至少 8 字元')
        salt=secrets.token_hex(16)
        hashed=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),600000).hex()
        with self.connect() as c:
            c.execute('INSERT INTO users VALUES(?,?,?,?)',(username,role,salt,hashed))
            if role=='client':
                c.execute('INSERT INTO cases(id,owner,updated) VALUES(?,?,?)',(uuid.uuid4().hex,username,time.time()))
    def authenticate(self, username, password, role):
        with self.connect() as c: u=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
        salt=bytes.fromhex(u['salt']) if u else b'not-a-user-salt'
        computed=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,600000).hex()
        return bool(u and u['role']==role and hmac.compare_digest(u['hash'],computed))
    def require(self, username, role):
        with self.connect() as c: u=c.execute('SELECT role FROM users WHERE username=?',(username,)).fetchone()
        if not u or u['role']!=role: raise PermissionError('沒有權限')
    def own_case(self, username):
        self.require(username,'client')
        with self.connect() as c: return dict(c.execute('SELECT * FROM cases WHERE owner=?',(username,)).fetchone())
    def case(self, case_id):
        with self.connect() as c: row=c.execute('SELECT * FROM cases WHERE id=?',(case_id,)).fetchone()
        if not row: raise ValueError('個案不存在')
        return dict(row)
    def messages(self, case_id):
        with self.connect() as c: return [dict(x) for x in c.execute('SELECT * FROM messages WHERE case_id=? ORDER BY created,rowid',(case_id,))]
    def add_message(self, case_id, role, text):
        mid=uuid.uuid4().hex
        with self.connect() as c:
            c.execute('INSERT INTO messages(id,case_id,role,content,created) VALUES(?,?,?,?,?)',(mid,case_id,role,text,time.time()))
            c.execute('UPDATE cases SET updated=? WHERE id=?',(time.time(),case_id))
        return mid
    def bot_message(self, case_id, text):
        with self.connect() as c:
            c.execute("INSERT INTO messages(id,case_id,role,content,created) SELECT ?,?,'bot',?,? WHERE EXISTS(SELECT 1 FROM cases WHERE id=? AND mode='bot')",(uuid.uuid4().hex,case_id,text,time.time(),case_id))
    def analysis(self, case_id, mid, result, mode):
        payload=json.dumps(result,ensure_ascii=False)
        with self.connect() as c:
            c.execute('UPDATE messages SET analysis=? WHERE id=?',(payload,mid))
            c.execute('UPDATE cases SET priority=MAX(priority,?),score=MAX(score,?),risk=?,updated=? WHERE id=?',(result['priority'],result['score'],payload,time.time(),case_id))
            if result['emergency']:
                report={'event_id':mid,'case_id':case_id,'message_id':mid,'assessment':result,'created':time.time()}
                # Only the triggering message is sent; no unrelated case history.
                report['message']=c.execute('SELECT content FROM messages WHERE id=?',(mid,)).fetchone()[0]
                c.execute('INSERT OR IGNORE INTO outbox(id,message_id,case_id,payload,status) VALUES(?,?,?,?,?)',(uuid.uuid4().hex,mid,case_id,json.dumps(report,ensure_ascii=False),'simulated' if mode=='dry_run' else 'pending'))
    def staff_mode(self, actor, case_id, mode):
        self.require(actor,'staff');self.case(case_id)
        if mode not in ('bot','human'): raise ValueError(mode)
        with self.connect() as c:
            c.execute('UPDATE cases SET mode=? WHERE id=?',(mode,case_id))
            c.execute('INSERT INTO audit(actor,action,case_id,created) VALUES(?,?,?,?)',(actor,'mode:'+mode,case_id,time.time()))
    def acknowledge(self, actor, case_id):
        self.require(actor,'staff');self.case(case_id)
        with self.connect() as c:
            c.execute('UPDATE cases SET priority=0,score=0 WHERE id=?',(case_id,))
            c.execute('INSERT INTO audit(actor,action,case_id,created) VALUES(?,?,?,?)',(actor,'reviewed_reset_priority',case_id,time.time()))
    def dashboard(self, actor):
        self.require(actor,'staff')
        with self.connect() as c: return [dict(x) for x in c.execute('SELECT * FROM cases ORDER BY priority DESC,score DESC,updated DESC')]
    def reports(self, actor, case_id):
        self.require(actor,'staff')
        with self.connect() as c: return [dict(x) for x in c.execute('SELECT id,status,attempts,error,receipt FROM outbox WHERE case_id=?',(case_id,))]
    def load_rules(self, rules):
        with self.connect() as c:
            c.execute('DELETE FROM rules')
            c.executemany('INSERT INTO rules VALUES(?,?)',[(k,json.dumps(v,ensure_ascii=False)) for k,v in rules.items()])
    def rules(self):
        with self.connect() as c: return {r['category']:json.loads(r['config']) for r in c.execute('SELECT * FROM rules')}
