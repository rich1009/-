import argparse,getpass,os,time,secrets
from pathlib import Path
os.environ.setdefault('GRADIO_ANALYTICS_ENABLED','False')
import gradio as gr
from config import Config
from service import Service

def username(request,role,service):
    actor='test_worker' if getattr(service,'test_mode',False) and role=='staff' else request.username
    service.db.require(actor,role)
    return actor

def prepare_test_users(service):
    for name,role in [('test_case_001','client'),('test_case_002','client'),('test_case_003','client'),('test_worker','staff')]:
        try: service.db.require(name,role)
        except PermissionError: service.db.add_user(name,secrets.token_urlsafe(24),role)

def build_apps(service,test_mode=False):
    service.test_mode=test_mode
    if test_mode: prepare_test_users(service)
    with gr.Blocks(title='個案對話') as client:
        gr.Markdown('# 個案對話\n訊息會保存供授權社工查看。AI 與風險篩檢可能有誤；本介面不保證即時有人回覆。')
        if test_mode:
            gr.Markdown('**免密碼測試模式：請僅使用虛構資料；所有人均可切換測試個案。**')
            test_account=gr.Dropdown(choices=['test_case_001','test_case_002','test_case_003'],value='test_case_001',label='測試個案')
        history=gr.Chatbot(label='我的對話',height=450)
        mode=gr.Textbox(label='回覆狀態',interactive=False)
        message=gr.Textbox(label='訊息',lines=3,max_length=8000)
        send=gr.Button('送出',variant='primary');refresh=gr.Button('更新社工回覆')
        if test_mode:
            def test_actor(account):
                if account not in ('test_case_001','test_case_002','test_case_003'): raise PermissionError('不是測試個案')
                return account
            def poll_test(account): return service.client_refresh(test_actor(account))
            def submit_test(text,account):
                h,m=service.send(test_actor(account),text)
                return '',h,m
            send.click(submit_test,[message,test_account],[message,history,mode],concurrency_limit=8,api_name='send_message')
            refresh.click(poll_test,[test_account],[history,mode],api_name='refresh')
            test_account.change(poll_test,[test_account],[history,mode],api_name=False)
            gr.Timer(3).tick(poll_test,[test_account],[history,mode],api_name=False)
            client.load(poll_test,[test_account],[history,mode])
        else:
            def poll(request:gr.Request): return service.client_refresh(username(request,'client',service))
            def submit(text,request:gr.Request):
                h,m=service.send(username(request,'client',service),text)
                return '',h,m
            send.click(submit,[message],[message,history,mode],concurrency_limit=8,api_name='send_message')
            refresh.click(poll,outputs=[history,mode],api_name='refresh')
            gr.Timer(3).tick(poll,outputs=[history,mode],api_name=False)
            client.load(poll,outputs=[history,mode])
    client.queue(default_concurrency_limit=8,max_size=128)
    with gr.Blocks(title='社工工作台') as staff:
        gr.Markdown('# 社工工作台\n風險分數是原型篩檢；恐懼與絕望是模型估計，需由社工核對。')
        board=gr.Dataframe(headers=['個案 ID','帳號','優先級','分數','模式','最近時間'],interactive=False,label='待處理個案（風險優先排序）')
        # Choices are presentation only; validate each selected ID against SQLite.
        # Dynamic choice updates can otherwise race Gradio preprocessing.
        with service.db.connect() as connection:
            initial_rows=connection.execute('SELECT id,owner,priority FROM cases ORDER BY priority DESC,score DESC,updated DESC').fetchall()
        initial_choices=[(r['owner']+'｜優先級 '+str(r['priority']),r['id']) for r in initial_rows]
        selector=gr.Dropdown(label='選擇個案',choices=initial_choices,
            value=initial_rows[0]['id'] if initial_rows else None,allow_custom_value=True)
        refresh=gr.Button('重新整理清單')
        chat=gr.Chatbot(label='個案對話',height=400)
        details=gr.JSON(label='評分依據、情緒、檢索與通報狀態')
        reply=gr.Textbox(label='社工回覆',lines=3,max_length=8000)
        respond=gr.Button('接手並回覆',variant='primary')
        with gr.Row():
            bot=gr.Button('恢復 AI 回覆');human=gr.Button('暫停 AI／由社工接手');review=gr.Button('已檢視／重設優先級')
        gr.Markdown('通報：simulated＝測試紀錄；pending/retry＝待送或重試；failed＝失敗；accepted＝介接端已接收，仍須核對受理結果。')
        report_id=gr.Textbox(label='失敗通報 ID');retry=gr.Button('重送失敗通報');retry_status=gr.Textbox(interactive=False)
        with gr.Accordion('知識庫管理',open=False):
            files=gr.File(file_count='multiple',file_types=['.txt','.md','.pdf','.docx','.json','.jsonl','.csv'],label='上傳家暴相關資料（不要放入其他個案私密對話）')
            ingest=gr.Button('加入 FAISS 索引');seed=gr.Button('將家暴關鍵用語加入索引');index_status=gr.Textbox(label='索引狀態',value=service.rag.status,interactive=False)
        def snapshot(cid,actor):
            rows=service.db.dashboard(actor)
            choices=[(r['owner']+'｜優先級 '+str(r['priority']),r['id']) for r in rows]
            ids={r['id'] for r in rows}
            selected=cid if cid in ids else (rows[0]['id'] if rows else None)
            table=[[r['id'],r['owner'],r['priority'],r['score'],r['mode'],time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(r['updated']))] for r in rows]
            history,assessment=service.staff_detail(actor,selected) if selected else ([],{})
            return table,gr.update(choices=choices,value=selected),history,assessment
        def selected_actor(cid,request):
            actor=username(request,'staff',service)
            if not cid or cid not in {r['id'] for r in service.db.dashboard(actor)}:
                raise gr.Error('請先從清單選擇有效的個案；可按重新整理清單更新。')
            return actor
        def detail(cid,request:gr.Request):
            actor=username(request,'staff',service)
            if cid is None: return [],{}
            return service.staff_detail(selected_actor(cid,request),cid)
        def staff_poll(cid,request:gr.Request):
            return snapshot(cid,username(request,'staff',service))
        def initial_load(request:gr.Request):
            return snapshot(None,username(request,'staff',service))
        def answer(cid,text,request:gr.Request):
            h,d=service.staff_reply(selected_actor(cid,request),cid,text)
            return '',h,d
        def resume(cid,request:gr.Request): return service.set_mode(selected_actor(cid,request),cid,'bot')
        def take(cid,request:gr.Request): return service.set_mode(selected_actor(cid,request),cid,'human')
        def ack(cid,request:gr.Request): return service.acknowledge(selected_actor(cid,request),cid)
        def upload(f,request:gr.Request): return service.ingest(username(request,'staff',service),f)
        def seed_rules(request:gr.Request): return service.seed_index(username(request,'staff',service))
        def retry_report(event,request:gr.Request):
            service.reporter.retry(username(request,'staff',service),event)
            return '已將符合條件的失敗紀錄排入重試；請查看狀態。'
        refresh.click(staff_poll,[selector],[board,selector,chat,details],api_name='list_cases',concurrency_limit=1,concurrency_id='staff_refresh')
        selector.input(detail,[selector],[chat,details],api_name='case_detail')
        respond.click(answer,[selector,reply],[reply,chat,details],api_name='staff_reply')
        bot.click(resume,[selector],[chat,details],api_name=False)
        human.click(take,[selector],[chat,details],api_name=False)
        review.click(ack,[selector],[chat,details],api_name=False)
        ingest.click(upload,[files],[index_status],api_name='ingest')
        seed.click(seed_rules,outputs=index_status,api_name='seed_index')
        retry.click(retry_report,[report_id],[retry_status],api_name=False)
        gr.Timer(3).tick(staff_poll,[selector],[board,selector,chat,details],api_name='poll_cases',concurrency_limit=1,concurrency_id='staff_refresh')
        staff.load(initial_load,outputs=[board,selector,chat,details])
    staff.queue(default_concurrency_limit=8,max_size=128)
    return client,staff

def main():
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command')
    add=sub.add_parser('add-user');add.add_argument('--username',required=True);add.add_argument('--role',choices=['client','staff'],required=True)
    sub.add_parser('run');args=parser.parse_args()
    config=Config()
    config.data=Path(__file__).parent/'data_test'
    config.report_mode='dry_run';config.webhook='';config.webhook_token=''
    config.host='127.0.0.1'
    service=Service(config)
    if args.command=='add-user':
        password=getpass.getpass('密碼（至少8字元）：')
        if password!=getpass.getpass('再次輸入：'): raise ValueError('兩次密碼不同')
        service.db.add_user(args.username,password,args.role);print('帳號已建立');return
    client,staff=build_apps(service,test_mode=True)
    print("免密碼測試版：個案可切換測試帳號，社工直接進入；通報僅模擬。")
    service.reporter.start()
    try:
        client.launch(server_name=config.host,server_port=config.client_port,auth=None,prevent_thread_lock=True,share=False,show_error=False)
        staff.launch(server_name=config.host,server_port=config.staff_port,auth=None,prevent_thread_lock=True,share=False,show_error=False)
        while True: time.sleep(1)
    except KeyboardInterrupt: pass
    finally:
        service.reporter.stop_event.set();client.close();staff.close()
if __name__=='__main__': main()
